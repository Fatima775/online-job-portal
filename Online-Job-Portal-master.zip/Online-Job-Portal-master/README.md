# Online-Job-Portal
An HTML based project designed for Sample.
Online Job Portal is a web-application which is developed with a vision to centralise the job seeking process. With Online Job Portal, job seekers and job recruiters can come on the same platform and simplify the process. The application will work as follows:

1.Job recruiters and job seekers will register on the platform.
2.Job recruiters will post vacancies in their respective firms.
3.Job seekers will apply for the iob of their choice.
4.Job recruiters will screen application through portal and call selected candidated for interview.
